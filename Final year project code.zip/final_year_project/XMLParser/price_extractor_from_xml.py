import xml.etree.cElementTree as ET
import sys
crop = sys.argv[1]
weight=sys.argv[2]
tree = ET.parse(crop+'.xml')
root=tree.getroot()
city_list = ['MUMBAI','VIJAYAWADA','JAIPUR','HYDERABAD','AHMEDABAD','BHUBANESHWAR','BANGALORE']
year_list = ['93','94','95','96','97','98','99','00','01','02','03','04','05','06','07','08','09','10','11','12']
f=open(crop+'_price.txt','w')
for city in city_list:
    for year in year_list:
        count = 0
        for child in root.iter('DATASET'):
            for element in child:
                if element[0].text[4] == '0' or element[0].text[4] == '1':
                    yr='1'+element[0].text[4:6]
                else :
                    yr=element[0].text[4:6]

                if element[2].text == city and ('01'+ year) ==  element[0].text[2:6]:
                    if element[3].text == 'NA':
                        print(element[2].text + " " + yr+" "+ element[3].text,file=f)
                    else:
                        price=float(element[3].text)/float(weight)
                        print(element[2].text + " " + yr+" "+ str(price),file=f)
                    count=count+1
                if element[2].text == city and ('09'+ year) ==  element[0].text[2:6]:
                    if element[3].text == 'NA':
                        print(element[2].text + " " + yr+" "+ element[3].text,file=f)
                    else:
                        price=float(element[3].text)/float(weight)
                        print(element[2].text + " " + yr+" "+ str(price),file=f)
                    count=count+1

            
        print("-----------------------------------",file=f)
    for i in range(count):
        print(city + " " + "113"+" "+ "10",file=f)
    print("-----------------------------------",file=f)
