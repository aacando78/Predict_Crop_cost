import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor


cities = ['ahmedabad','bangalore','bhubaneshwar','hyderabad','jaipur','mumbai','vijayawada']
crops = ['rice','wheat']

for crop in crops:
  r2_arr = []
  for city in cities:
    ## Reading the dataset
    dataset=pd.read_csv('finalcsvoutputs/'+city+'_'+crop+'.csv')
    X=dataset.iloc[:,1:4].values
    y=dataset.iloc[:,4].values

    ##Taking care of missing values
    from sklearn.preprocessing import Imputer
    imputer=Imputer(missing_values='NaN',strategy='mean' ,axis=0)
    imputer=imputer.fit(X[:,2:3])
    X[:,2:3]=imputer.transform(X[:,2:3])
    sum=max(y)
    for val in range(0,len(y)):
        if(int(y[val])==0):
            y[val]=round(sum,2)

    ## Applying polynomial function
    polynomial_features= PolynomialFeatures(degree=1)
    X = polynomial_features.fit_transform(X)

    ## Splitting dataset into train and test
    X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=0)

    ## Applying Regression
    regressor=LinearRegression()
    regressor.fit(X_train,y_train)

    ## Decison tree regressor
    # regressor  = DecisionTreeRegressor(random_state=0)
    # regressor.fit(X_train,y_train)

    ##Predicting values
    y_pred = regressor.predict(X_test)

    ## Getting r2 score
    r2_arr.append(r2_score(y_test,y_pred))

  print(crop)  
  print(np.mean(r2_arr))
  print()

