import pandas as pd
import sys
crop=sys.argv[1]


def price_spei_csv(place):
    place = place.lower()
    data=pd.read_csv("spei_inputs/"+place+"_spei.csv")
    start=1105
    end=1344
    temp=[]
    final=[]
    for i in range(start,end+1,12):
        for m in range(i,i+12):
            val=data["Col"][m]
            if(val=='NA'):
                val=5.5
            temp.append(float(val))
        temp.sort()
        final.append(temp[0])
        temp=[]
    j=1993
    year=[]
    for i in range(0,20):
        year.append(j)
        j=j+1
    dict={'Year':year,"SPEI":final,"Prev_price":x,"After_price":y}
    
    df=pd.DataFrame(dict)
    df.to_csv("finalcsvoutputs/"+place+"_"+crop+".csv")



file=open("../XMLParser/"+crop+"_price.txt","r")
fileread=file.readlines()
price=[]
line=[]
city_price=[]
checkNA=0
for word in range(0,len(fileread)):
    if(fileread[word]!="-----------------------------------\n"):
        strval=fileread[word].split(" ")
        if(strval[2]!='NA\n'):
              checkNA+=1
              city_pri=strval[0]+" "+strval[1]+" "+strval[2]
              city_price.append(city_pri)
              line.append(word)
    
        if(fileread[word+1]=="-----------------------------------\n"):
            if(checkNA<2):
                for i in range(0,2):
                    city_pri=strval[0]+" "+strval[1]+" "+str(-100)
                    city_price.append(city_pri)
         
    if(fileread[word]=="-----------------------------------\n"):
        checkNA=0

       
             
x=[]
y=[]
temp=[]

def gettingYearmax_min(arr):
    arr.sort()
    if(arr[0]==-100 and arr[-1]==-100):
        x.append('NA')
        y.append(0)
    else:
        x.append(arr[0])
        y.append(arr[-1])
k=93
count=0

try:
    for i in city_price:
    
        sp=i.split()
        
        if count == 20:
            price_spei_csv(sp[0])
            count=0
            x=[]
            y=[]
            temp=[]
            k=93
    
        if(int(sp[1][0:])==k+1):
            k=k+1
            
            if sp[1][0:] == '94':
                temp=temp[3:]
            
            gettingYearmax_min(temp)
            temp=[]
            count=count+1
        else:
            temp.append(float(sp[2]))
except Exception as e:
    print(e)


