
def predict(crop,choice,year,current_price,some_ratio=-1.7):
  import pandas as pd
  import numpy as np
  dataset=pd.read_csv('../csvmaker/finalcsvoutputs/'+choice.lower()+'_'+crop+'.csv')
  X=dataset.iloc[:,1:4].values
  y=dataset.iloc[:,4].values
  from sklearn.preprocessing import Imputer
  imputer=Imputer(missing_values='NaN',strategy='mean' ,axis=0)
  imputer=imputer.fit(X[:,2:3])
  X[:,2:3]=imputer.transform(X[:,2:3])
  print(type(y))
  #sum=0
  '''for val in y:
    print(val)
    if(val):
        sum+=float(val)'''
  sum=max(y)
  for val in range(0,len(y)):
      if(int(y[val])==0):
          y[val]=round(sum,2)
  from sklearn.linear_model import LinearRegression
  regressor=LinearRegression()
  regressor.fit(X,y)
  y_pred=regressor.predict(np.array([[float(year),float(some_ratio),float(current_price)]]))
  y_pred = round(y_pred[0],2)
  y_pred = str(y_pred)+" ₹"
  return str(current_price)+" ₹",y_pred
