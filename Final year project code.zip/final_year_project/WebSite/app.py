from flask import Flask,render_template,url_for,request
app = Flask(__name__)


import drought_second_prototype as drought


@app.route('/')
def load_home():
    return render_template('index.html')

@app.route('/predict')
def predict_form():
    return render_template('generic.html')

@app.route('/predict',methods=['POST'])
def predict_post_form():
	if request.form['spei']:
		current_price,predicted_price=drought.predict(request.form['crop'],request.form['city'],request.form['year'],request.form['price'],request.form['spei'])
	else:
		current_price,predicted_price=drought.predict(request.form['crop'],request.form['city'],request.form['year'],request.form['price'])
	return render_template('generic.html',current_price="The current price is : "+current_price,predicted_price="The predicted price is : "+predicted_price)

@app.route('/team')
def team():
    return render_template('elements.html')

if __name__ == '__main__':
    app.run()